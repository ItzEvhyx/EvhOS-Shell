EvhOs Satin custom icon pack

60 generated icon designs in 16, 22, 24, 32, 48, 64, 96, 128 and 256 px PNG sizes.
All PNGs have real transparent backgrounds. These are raster assets, not SVGs.

Selected customizations:
- Ski: layered blue folder with raised tab and paper inserts.
- Cursor: existing folded cube identity in graphite/silver Satin materials.
- Resources: Contour monitor and green waveform with silver frame and stand.
- Postman: Contour astronaut and orbit rendered with orange Satin materials.

The installer creates user-local desktop overrides, updates GTK and Qt icon
theme settings, updates cached Serpantinum dock icons and saved desktop presets,
and restarts Serpantinum. Every changed file is backed up. Launch commands,
MIME associations, startup classes and application behavior are preserved.
No root privileges, package changes or network downloads are required.
New apps installed later use Adwaita/hicolor fallback until icons are added.

Installer options:
  python3 install-evhos-satin.py --check
  python3 install-evhos-satin.py --dry-run
  python3 install-evhos-satin.py
  python3 install-evhos-satin.py --no-restart
  python3 install-evhos-satin.py --restore

Desktop theme format:
https://specifications.freedesktop.org/icon-theme/latest/
Desktop launcher icon key:
https://specifications.freedesktop.org/desktop-entry/latest/recognized-keys.html

Generated custom interpretations of application marks; application names and
trademarks belong to their respective owners.
